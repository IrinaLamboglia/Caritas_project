
contenido_actual = """
Somos Cáritas Argentina, una organización de la Iglesia Católica que trabaja para dar respuesta a las problemáticas sociales que derivan de la pobreza.
Somos más de 40.000 voluntarios en 3.500 equipos de trabajo y estamos en todos los rincones del país.
Acompañamos a personas, familias y comunidades que se encuentran en situación de exclusión y vulnerabilidad.
Les brindamos contención espiritual y herramientas concretas para que, por sus propios medios, sean capaces de transformar su realidad.
"""
