SELECT * FROM core_usuario;

